
class Array
{ 
	
public static void main(String args[])
{ 
	
int a[]=new int[5]; 
a[0]=20;
a[1]=40;  
a[2]=70;  
a[3]=90;  
a[4]=95;  

for(int i=0;i<a.length;i++)
System.out.println(a[i]);  
}

}  
